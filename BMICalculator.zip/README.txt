# BMI Calculator

## Overview

A simple command-line application that calculates Body Mass Index (BMI).

## Features

- Input weight and height to get BMI.

## Technologies Used

- Java

## How to Run

1. Compile the program: `javac BMICalculator.java`

2. Run the program: `java BMICalculator`